# JPG-and-PNG-to-MNIST

clone by https://github.com/gskielian/JPG-PNG-to-MNIST-NN-Format.git


1. ./resize-script-insta.sh 
2. python convert-images-to-mnist-format-insta.py
